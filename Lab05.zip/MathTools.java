/**
 * Created by KennyZheng on 2/7/16.
 */

import java.lang.*;

public class MathTools {

    public static double absoluteValue(double n) {

        if (n <= 0) {
            return n * -1;
        } else
            return n;
    }

    public static double power(double base, int exponent) {

        double answer = base;

        if (exponent == 0) {
            return 1;
        }

        if (exponent > 0) {
            for (int i = 1; i < exponent; i++) {
                answer *= base;
            }
        } else {
            exponent = (int) absoluteValue(exponent);
            for (int i = 1; i < exponent; i++) {
                answer *= base;
            }
            return 1 / answer;
        }

        return answer;
    }

    public static double nthRoot(double value, int root) {

        double initialGuess = 0;
        double newGuess = 0;
        double deltaX = 0;
        double tolerance = 0.000000001;

        if (root == 0) {
            return 0;
        } else if (root > 0) {
            initialGuess = value;
        } else {
            initialGuess = 1 / value;
        }

        if (value <= 0) {
            return 0;
        }

        do {
            newGuess = (1.0 / root) * ((root - 1) * initialGuess + (value / power(initialGuess, root - 1)));
            deltaX = absoluteValue(newGuess - initialGuess);
            initialGuess = newGuess;
        } while (deltaX > tolerance);

        return newGuess;
    }

    public static String scientificNotation(double n) {

        int counter = 0;
        boolean keepGoing = true;
        String answer = "";

        if (n < 1) {
            while (keepGoing) {
                n *= 10;
                String s = Double.toString(n);
                if (s.charAt(0) == '0') {
                    keepGoing = true;
                } else {
                    keepGoing = false;
                }
                counter++;
            }

            n = ((int) (n * 1000000)) / 1000000.0;
            answer = n + " x 10 ^ -" + counter;
            return answer;
        } else if (n > 9) {
            String s = Double.toString(n);
            for (int i = s.indexOf('.') - 1; i > 0; i--) {
                n /= 10;
                counter++;

            }

            n = ((int) (n * 1000000)) / 1000000.0;
            answer = n + " x 10 ^ " + counter;
            return answer;
        } else {
            n = ((int) (n * 1000000)) / 1000000.0;
            answer = n + " x 10 ^ 0";
            return answer;
        }
    }
}