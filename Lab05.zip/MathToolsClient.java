/**
 * Created by KennyZheng on 2/8/16.
 */
import java.util.Scanner;

public class MathToolsClient {
    public static void main(String[] args) {

        MathTools m = new MathTools();
        boolean keepGoing;

        do {
            Scanner s = new Scanner(System.in);

            System.out.println("Select a number from the menu choices:");
            System.out.println("1 - Absolute Value");
            System.out.println("2 - Power");
            System.out.println("3 - Nth Root");
            System.out.println("4 - Scientific Notation");

            int choice = s.nextInt();

            if (choice == 1) {
                System.out.println("***Absolute Value***");
                System.out.println("Enter a number");
                double absNumber = s.nextDouble();
                double answer = m.absoluteValue(absNumber);
                System.out.println("The answer is: " + answer);
            } else if (choice == 2) {
                System.out.println("***Power***");
                System.out.println("Enter a base");
                double powerBase = s.nextDouble();
                System.out.println("Enter a exponent");
                int powerExponent = s.nextInt();
                double answer = m.power(powerBase, powerExponent);
                System.out.println("The answer is:" + answer);
            } else if (choice == 3) {
                System.out.println("***Nth Root***");
                System.out.println("Enter a value");
                double nthRootValue = s.nextDouble();
                System.out.println("Enter a root");
                int nthRootRoot = s.nextInt();
                double answer = m.nthRoot(nthRootValue, nthRootRoot);
                System.out.println("The answer is: " + answer);
            } else if (choice == 4) {
                System.out.println("***Scientific Notation***");
                System.out.println("Enter a number");
                double notationNumber = s.nextDouble();
                String answer = m.scientificNotation(notationNumber);
                System.out.println("The answer is: " + answer);
            } else
                System.out.println("Invalid Option.");

            System.out.println("\nReturn to the menu? (yes/no)");
            s.nextLine();
            String restart = s.nextLine();
            if (restart.equalsIgnoreCase("yes")) {
                keepGoing = true;
            } else {
                keepGoing = false;
                System.out.println("Exiting MathToolsClient...");
            }
        } while (keepGoing);
    }
}