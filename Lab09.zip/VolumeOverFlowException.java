/**
 * Created by KennyZheng on 3/6/16.
 */
public class VolumeOverFlowException extends Exception {

    public VolumeOverFlowException (String message) {
        super(message);
    }

    private VolumeOverFlowException () {
        super();
    }

}
