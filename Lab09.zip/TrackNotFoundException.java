/**
 * Created by KennyZheng on 3/6/16.
 */
public class TrackNotFoundException extends Exception {

    public TrackNotFoundException (String message) {
        super(message);
    }

    public TrackNotFoundException () {
        super();
    }
}
