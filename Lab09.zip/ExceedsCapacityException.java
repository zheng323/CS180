/**
 * Created by KennyZheng on 3/6/16.
 */
public class ExceedsCapacityException extends Exception {

    public ExceedsCapacityException (String message) {
        super(message);
    }

    public ExceedsCapacityException () {
        super();
    }
}
