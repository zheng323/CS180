public enum OrderSize {
    SMALL, MEDIUM, LARGE, ABSURD
}