public enum Spicyness {
    MILD, MEDIUM, HOT, CRAZY, INSANE
}