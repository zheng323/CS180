import java.util.Map;

/**
 * Created by KennyZheng on 3/4/16.
 */
public class Sandwich implements PurchasedItem {

    private String name;
    private double matCost;
    private double sellPrice;
    private int delTime;
    private Spicyness level;
    private int condiments;
    public static double costOfCondiment = 0.05;
    public static double pricePerCondiment = 0.75;

    public Sandwich(String name, double matCost, double sellPrice, int delTime, Spicyness level, int condiments) {
        this.name = name;
        this.matCost = matCost;
        this.sellPrice = sellPrice;
        this.delTime = delTime;
        this.level = level;
        this.condiments = condiments;
    }

    public Sandwich(String name, double matCost, double sellPrice) {
        this(name, matCost, sellPrice, 0, Spicyness.MILD, 0);
    }

    public Sandwich(String name, double matCost) {
        this(name, matCost, 3.5 * matCost, 0, Spicyness.MILD, 0);
    }

    public boolean isDelivery() {
        if (delTime <= 0) {
            return false;
        } else if (delTime > 60) {
            return false;
        } else {
            return true;
        }
    }

    public String getCustomerName() {
        return name;
    }

    public int getDeliveryTime() {
        return this.delTime;
    }

    public void setDeliveryTime(int time) {
        if (time < 0) {
            this.delTime = 0;
        } else
            this.delTime = time;
    }

    public double getMaterialCost() {

        if (this.condiments > 0) {
            return this.matCost + this.condiments * costOfCondiment;
        } else {
            return this.matCost;
        }
    }

    public double getSalePrice() {

        if (this.condiments > 0) {
            return this.sellPrice + this.condiments * pricePerCondiment;
        } else {
            return this.sellPrice;
        }
    }

    public Spicyness getSpicyness() {
        return this.level;
    }

    public void setSpicyness(Spicyness level) {
        this.level = level;
    }

    public void addCondiments(int num) {
        this.condiments += num;
    }

    public void removeCondiments(int num) {
        if (this.condiments <= num) {
            this.condiments = 0;
        } else
            this.condiments -= num;
    }

    public int getNumCondiments() {
        return condiments;
    }

    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (obj instanceof Sandwich) {
            Sandwich sand = (Sandwich) obj;
            if ((Math.abs(sand.getSalePrice() - this.sellPrice) < 0.01)
                    && (Math.abs(sand.getMaterialCost() - this.matCost) < 0.01) &&
                    sand.getCustomerName().equals(this.name) && sand.getDeliveryTime() == this.delTime &&
                    sand.getSpicyness() == this.level) {
                return true;
            }
        }

        return false;
    }
}