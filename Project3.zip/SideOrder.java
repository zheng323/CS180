import java.util.Map;

/**
 * Created by KennyZheng on 3/4/16.
 */
public class SideOrder implements PurchasedItem {

    private String name;
    private double matCost;
    private double sellPrice;
    private int delTime;
    private OrderSize size;

    public SideOrder(String name, double matCost, double sellPrice) {
        this(name, matCost, sellPrice, 0, OrderSize.SMALL);
    }
    public SideOrder(String name, double matCost, double sellPrice, int delTime) {
        this(name, matCost, sellPrice, delTime, OrderSize.SMALL);
    }

    public SideOrder(String name, double matCost, double sellPrice, int delTime, OrderSize size) {
        this.name = name;
        this.matCost = matCost;
        this.sellPrice = sellPrice;
        this.delTime = delTime;
        this.size = size;
    }

    public boolean isDelivery() {
        if (delTime <= 0 || delTime > 30) {
            return false;
        } else
            return true;
    }

    public String getCustomerName() {
        return name;
    }

    public int getDeliveryTime() {
        return delTime;
    }

    public void setDeliveryTime(int time) {
        delTime = time >= 0 ? time : 0;
    }

    public double getMaterialCost() {

        if (this.size == OrderSize.SMALL) {
            matCost = matCost + 0.00;
        } else if (this.size == OrderSize.MEDIUM) {
            matCost = matCost + 0.40;
        } else if (this.size == OrderSize.LARGE) {
            matCost = matCost + 0.80;
        } else if (this.size == OrderSize.ABSURD) {
            matCost = matCost + 1.50;
        }

        return matCost;
    }

    public double getSalePrice() {
        if (this.size == OrderSize.SMALL) {
            sellPrice = sellPrice + 0.00;
        } else if (this.size == OrderSize.MEDIUM) {
            sellPrice = sellPrice + 2.00;
        } else if (this.size == OrderSize.LARGE) {
            sellPrice = sellPrice + 3.00;
        } else if (this.size == OrderSize.ABSURD) {
            sellPrice = sellPrice + 4.50;
        }

        return sellPrice;
    }
    
    public OrderSize getOrderSize() {
        return size;
    }

    public void setOrderSize(OrderSize size) {
        this.size = size;
    }

    public boolean equals (Object obj) {

        if (obj instanceof SideOrder) {
            SideOrder so = (SideOrder) obj;
            if (so.getCustomerName().equals(this.name) &&
                    (Math.abs(so.getMaterialCost() - this.matCost) < 0.01) &&
                    (Math.abs(so.getSalePrice() - this.sellPrice) < 0.01) && so.getDeliveryTime() == this.delTime
                    && so.getOrderSize() == this.size) {
                return true;
            }
        }

        return false;
    }
}
