import java.util.Random;
import java.util.Scanner;

/**
 * Created by KennyZheng on 2/5/16.
 */
public class Player {

    String name;
    int score;
    Random dice = new Random();

    private static final String LOSE_MESSAGE = "\tDice values: %s, Sorry, you scored 0 for the round\n\n";
    private static final String THROW_DICE_MESSAGE = "\tDice values: %s, %d + %d = %d points!\n";
    private static final String ALL_DICE_SCORED_MESSAGE = "\tYou have to relaunch the %d dice\n\n";
    private static final String NOT_MULTIPLE_OF_100_MESSAGE = "\tYou have to continue, "
            + "the score is not a multiple of 100\n\n";
    private static final String CONTINUE_MESSAGE = "\tContinue with %d dice? Current score: %d points (Y/N)\n";
    private static final String ROUND_SCORE_MESSAGE = "\tSuper you scored %d for the round!! Your new score is %d\n\n";

    public Player(String name) {
        this.name = name;
        this.dice = new Random();
        this.score = 0;

    }

    public String throwDice(int nbDice) {

        String diceValues = "";
        int toalDice = nbDice;

        for (int i = 0; i < toalDice; i++) {
            int dieVal = dice.nextInt(6) + 1;
            diceValues += dieVal + " ";
        }

        return diceValues;
    }

    public int nbDiceScored(String diceValues) {

        int val = 0;

        Scanner s = new Scanner(diceValues);

        while (s.hasNextInt()) {
            int value = s.nextInt();
            if (value == 1 || value == 5) {
                val++;
            }
        }

        return val;
    }

    public int countPoints(String diceValues) {

        int val = 0;

        Scanner s = new Scanner(diceValues);

        while (s.hasNextInt()) {
            int value = s.nextInt();
            if (value == 1) {
                val += 100;
            } else if (value == 5) {
                val += 50;
            }
        }

        return val;
    }

    public boolean continueRound(int nbDice) {

        String enterContinue;
        Scanner s = new Scanner(System.in);

        do {
            System.out.printf(CONTINUE_MESSAGE, nbDice, score);
            enterContinue = s.next();
        } while ((!(enterContinue.equals("Y"))) && (!(enterContinue.equals("N"))));

        if (enterContinue.equals("Y")) {
            return true;
        } else
            return false;
    }

    public boolean isWinner() {

        if (score >= 5000) {
            return true;
        } else
            return false;

    }

    public void playRound() {

        String diceValue;
        int newDice = 5;
        int throwScore;
        int roundPoints = 0;
        int diceScore;
        boolean keepGoing = true;

        do {

            diceValue = throwDice(newDice);
            throwScore = countPoints(diceValue);
            diceScore = nbDiceScored(diceValue);

            if (throwScore == 0) {
                System.out.printf(LOSE_MESSAGE, diceValue);
                return;
            }

            System.out.printf(THROW_DICE_MESSAGE, diceValue, roundPoints, throwScore, roundPoints + throwScore);

            newDice = newDice - diceScore;

            roundPoints += throwScore;

            if (newDice == 0) {
                newDice = 5;
                System.out.printf(ALL_DICE_SCORED_MESSAGE, newDice);
            } else if (roundPoints % 100 == 0) {
                if (continueRound(newDice)) {
                    keepGoing = true;
                } else {
                    System.out.printf(ROUND_SCORE_MESSAGE, roundPoints, this.score + roundPoints);
                    this.score += roundPoints;
                    keepGoing = false;
                }
            } else {
                System.out.printf(NOT_MULTIPLE_OF_100_MESSAGE);
                keepGoing = true;
            }
        } while (keepGoing);
    }
}