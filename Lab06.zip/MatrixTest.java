/**
 * Created by KennyZheng on 2/13/16.
 */
import static org.junit.Assert.*;
import org.junit.*;

public class MatrixTest {

    private Matrix m;

    @Before
    public void setup() throws Exception {
        m = new Matrix();
    }

    @Test(timeout = 100)
    public void testisSymmetric() {

        boolean actual = m.isSymmetric(new int[][]{
                {0,1,0},
                {1,0,1},
                {0,1,0}});
        boolean expected = true;
        assertEquals(expected,actual);
    }

    @Test(timeout = 100)
    public void testisSymmetric2() {

        boolean actual = m.isSymmetric(new int[][]{
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}});
        boolean expected = false;
        assertEquals(expected, actual);
    }

    @Test(timeout = 100)
    public void testisSymmetric3() {

        boolean actual = m.isSymmetric(new int[][]{
                {1, 2},
                {4, 5, 6},
                {7, 8, 9}});
        boolean expected = false;
        assertEquals(expected, actual);
    }

    @Test(timeout = 100)
    public void isDiagonal() {

        boolean actual = m.isDiagonal(new int[][]{
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}});
        boolean expected = false;
        assertEquals(expected,actual);
    }

    @Test(timeout = 100)
    public void isDiagonal2() {

        boolean actual = m.isDiagonal(new int[][]{
                {0,0,0},
                {0,0,0},
                {0,0,0}});
        boolean expected = true;
        assertEquals(expected,actual);
    }

    @Test(timeout = 100)
    public void isDiagonal3() {

        boolean actual = m.isDiagonal(new int[][]{
                {1, 0, 0},
                {0, 2, 0},
                {0, 0, 3}});
        boolean expected = true;
        assertEquals(expected,actual);
    }

    @Test(timeout = 100)
    public void isIdentity() {

        boolean actual = m.isIdentity(new int[][]{
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}});
        boolean expected = false;
        assertEquals(expected,actual);
    }

    @Test(timeout = 100)
    public void isIdentity2() {

        boolean actual = m.isIdentity(new int[][]{
                {1, 0, 0},
                {0, 1, 0},
                {0, 0, 1}});
        boolean expected = true;
        assertEquals(expected,actual);
    }

    @Test(timeout = 100)
    public void isIdentity3() {

        boolean actual = m.isIdentity(new int[][]{
                {1, 0, 0},
                {0, 1, 0, 0},
                {0, 0, 1, 0},
                {0, 0, 0, 1}});
        boolean expected = false;
        assertEquals(expected,actual);
    }

    @Test(timeout = 100)
    public void isUpperTriangular() {

        boolean actual = m.isUpperTriangular(new int[][]{
                {1, 0, 0},
                {0, 1, 0},
                {0, 0, 1}});
        boolean expected = true;
        assertEquals(expected,actual);
    }

    @Test(timeout = 100)
    public void isUpperTriangular2() {

        boolean actual = m.isUpperTriangular(new int[][]{
                {1,2,3},
                {0,5,6},
                {0,0,9}});
        boolean expected = true;
        assertEquals(expected,actual);
    }

    @Test(timeout = 100)
    public void isUpperTriangular3() {

        boolean actual = m.isUpperTriangular(new int[][]{
                {1,2,3},
                {4,5,6},
                {7,8,9}});
        boolean expected = false;
        assertEquals(expected,actual);
    }

    @Test(timeout = 100)
    public void isisTriDiagonal() {

        boolean actual = m.isTriDiagonal(new int[][]{
                {1, 2, 0},
                {2, 1, 2},
                {0, 2, 1}});
        boolean expected = true;
        assertEquals(expected, actual);

    }

    @Test(timeout = 100)
    public void isisTriDiagonal2() {

        boolean actual = m.isTriDiagonal(new int[][]{
                {1, 0, 0},
                {0, 1, 0},
                {0, 0, 1}});
        boolean expected = false;
        assertEquals(expected, actual);
    }

    @Test(timeout = 100)
    public void isisTriDiagonal3() {

        boolean actual = m.isTriDiagonal(new int[][]{
                {1, 2, 0, 0},
                {4, 5, 6, 0},
                {0, 8, 9, 1},
                {0, 0, 3, 4}});
        boolean expected = true;
        assertEquals(expected, actual);
    }

}