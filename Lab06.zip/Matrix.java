/**
 * Created by KennyZheng on 2/13/16.
 */
public class Matrix {

    public boolean isSymmetric(int[][] matrix) {

        if (matrix.length != matrix[0].length)
            return false;

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                if (matrix[i][j] != matrix[j][i]) {
                    return false;

                    // if (matrix[i][j] == matrix[j][i]) {  //DOESN'T WORK?
                    // return true;
                }
            }
        }

        return true;
        // return false;
    }

    public boolean isDiagonal(int[][] matrix) {

        int counter = 0;

        if (matrix.length != matrix[0].length)
            return false;

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                if (i != j) {
                    int number = matrix[i][j];
                    if (number != 0) {
                        counter ++;
                    }
                }
            }
        }

        if (counter != 0) {
            return false;
        } else {
            return true;
        }
    }

    public boolean isIdentity(int[][] matrix) {

        int counter = 0;

        if (matrix.length != matrix[0].length)
            return false;

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                if (i == j) {
                    if (matrix[i][j] != 1) {
                        counter++;
                    }
                } else if (i != j) {
                    if (matrix[i][j] != 0) {
                        counter++;
                    }
                }
            }
        }

        if (counter != 0) {
            return false;
        } else
            return true;
    }

    public boolean isUpperTriangular(int[][] matrix) {

        if (matrix.length != matrix[0].length)
            return false;

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < i; j++) {
                if (matrix[i][j] == 0) {
                    return true;
                }
            }
        }

        return false;
    }

    public boolean isTriDiagonal(int[][] matrix) {

        if (matrix.length != matrix[0].length)
            return false;

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                int number = matrix[i][j];

                if (i == j || i - 1 == j || i + 1 == j) {
                    if (number == 0) {
                        return false;
                    }
                } else {
                    if (number == 0) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
}
