/**
 * CS180 - Lab 02
 * Calculate the pythagoras to the console.
 * @author Kenny Zheng, zheng323@purdue.edu, L04
 */

public class Pythagoras {
    public double getHypotenuse(int a, int b) {
        double result;
        result = Math.sqrt(a * a + b * b);
        return result;
    }

}
