import java.util.concurrent.atomic.AtomicInteger;

public class Counter2 implements Counter {

    private int value = 0;

    private AtomicInteger AI = new AtomicInteger(value);

    public void inc() {
        value = AI.incrementAndGet();
    }

    public void dec() {
        value = AI.decrementAndGet();
    }

    public final int get() {
        return AI.get();
    }
}