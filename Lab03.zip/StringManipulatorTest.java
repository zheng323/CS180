import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * JUnit test case class for testing the functionality of methods from the StringManipulator class.
 */


public class StringManipulatorTest {

    private StringManipulator sm;

    @Before
    public void setUp() throws Exception {
        sm = new StringManipulator();
    }

    @Test(timeout = 100)
    public void testMakeUserNameBasic() {

        String ret = sm.makeUserName("john doe");
        String message = "makeUserName(): check if username follows the basic Unix style structure";
        assertEquals(message, "jdoe", ret);

    }

    @Test(timeout = 100)
    public void testMakeUserNameLower() {

        String ret = sm.makeUserName("JOHN DOE");
        String message = "makeUserName(): check if username convert upper letters to lower letters";
        assertEquals(message, "jdoe", ret);

    }

    @Test(timeout = 100)
    public void testMakeEmail() {

        String ret = sm.makeEmail("john doe", "PURDUE.EDU");
        String message = "makeEmail(): check if makeEmail works";
        assertEquals(message, "jdoe@purdue.edu", ret);

    }
}

