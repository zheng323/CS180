/**
 * CS180 - Lab 03
 * String Manipulator
 * @author Kenny Zheng, zheng323@purdue.edu, L04
 */

import java.util.Scanner;

public class StringManipulator {

    public String makeUserName(String fullName) {

        String fInit;
        String lastName;
        String upperName;
        String name;
        int spaceLocation;

        fInit = fullName.substring(0, 1);
        spaceLocation = fullName.indexOf(" ");
        lastName = fullName.substring(spaceLocation + 1);
        upperName = fInit.concat(lastName);
        name = upperName.toLowerCase();

        return name;
    }

    public String makeEmail (String name, String domain) {

        String lowerDomain;
        String email;

        lowerDomain = domain.toLowerCase();
        email = makeUserName(name) + "@" + lowerDomain;

        return email;
    }

    public static void main (String[] args) {

        StringManipulator sm = new StringManipulator();
        Scanner s = new Scanner(System.in);

        String finalName;
        String finalDomain;

        System.out.printf("Enter the Full Name of the person. First Name followed by Last Name: ");
        String enteredName = s.nextLine();
        finalName = sm.makeUserName(enteredName);
        System.out.printf("Enter the domain: ");
        String enteredDomain = s.nextLine();
        finalDomain = sm.makeEmail(enteredName, enteredDomain);
        System.out.println("The user name for the person is: " + finalName);
        System.out.println("The email id for the person is: " + finalDomain);

    }
}
