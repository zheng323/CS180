/**
 * CS180 - Lab 01
 * This is my first Java program. It prints calculate temperature to the console.
 * @author Kenny Zheng, zheng323@purdue.edu, L04
 */
public class Temperature {
    public static void main (String[] args) {
        double fahrenheit;
        double celsius;
        fahrenheit = 212;
        celsius = ((fahrenheit - 32) * 5) / 9;
        System.out.println("Fahrenheit: " + fahrenheit);
        System.out.println("Celsius: " + celsius);
    }
}
