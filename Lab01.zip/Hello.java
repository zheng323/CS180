/**
 * CS180 - Lab 01
 * This is my first Java program. It prints "Hello, World!" to the console.
 * @author Kenny Zheng, zheng323@purdue.edu, L04
 */
public class Hello {
    public static void main (String[] args) {
        System.out.println("Hello, World!");
    }
}
