import java.util.*;

/**
 * CS 180 - Project 2 - Obstruction
 * <p>
 * This class provides the skeleton methods you need to implement and
 * runs the in-console UI to play the game in the main method.
 *
 * @author Kenny Zheng
 */
public class ObstructionGame {

    // game variables
    public char[][] gameBoard;
    public char[][] screen;

    // display variables
    public static boolean usingLargeBoard = true;
    public static int numPixels = 6;

    // variable constants
    private static final char DOT = '.';
    private static final char STAR = '*';
    private static final char PLUS = '+';
    private static final char EMPTY = ' ';
    private static final char CROSS = 'X';
    private static final char CIRCLE = 'O';

    /**
     * Initializes all instance variables (such as gameBoard) used to
     * run the game. You may create other variables if you wish.
     *
     * @param rows number of rows on the board
     * @param cols number of columns on the board
     */
    public ObstructionGame(int rows, int cols) {

        int newRows = rows * numPixels;
        int newCols = cols * numPixels;

        gameBoard = new char[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                gameBoard[i][j] = EMPTY;
            }
        }

        screen = new char[newRows][newCols];
        for (int i = 0; i < rows * numPixels; i++) {
            for (int j = 0; j < cols * numPixels; j++) {
                screen[i][j] = EMPTY;
            }
        }
    }


    /**
     * Updates the board with the player's move.
     *
     * @param row    the row of the move
     * @param col    the column of the move
     * @param player the player who is making the move.
     * @return false if the location or player is not a legal spot
     * or player, true otherwise
     */
    public boolean playAtLocation(int row, int col, char player) {

        for (int i = row; i < gameBoard.length; i++) {
            for (int j = col; j < gameBoard[0].length; j++) {
                if (gameBoard[i][j] == EMPTY) {
                    if (player == CIRCLE && gameBoard[i][j] != CIRCLE) {
                        gameBoard[i][j] = player;
                        putDot(row, col);
                        updateScreen(row, col);
                        return true;
                    } else if (player == CROSS && gameBoard[i][j] != CROSS) {
                        gameBoard[i][j] = player;
                        putDot(row, col);
                        updateScreen(row, col);
                        return true;
                    }

                } else

                    return false;
            }
        }

        return false;
    }

    public void putDot(int i, int j) {

        // top left
        if (i == 0 && j == 0) {
            gameBoard[i][j + 1] = DOT;
            gameBoard[i + 1][j] = DOT;
            gameBoard[i + 1][j + 1] = DOT;

            // top right
        } else if (i == 0 && j == (gameBoard[0].length - 1)) {
            gameBoard[i][j - 1] = DOT;
            gameBoard[i + 1][j] = DOT;
            gameBoard[i + 1][j - 1] = DOT;

            // top margin
        } else if (i == 0) {
            gameBoard[i][j - 1] = DOT;
            gameBoard[i][j + 1] = DOT;
            gameBoard[i + 1][j - 1] = DOT;
            gameBoard[i + 1][j] = DOT;
            gameBoard[i + 1][j + 1] = DOT;

            // bottom left
        } else if (i == (gameBoard.length - 1) && j == 0) {
            gameBoard[i - 1][j] = DOT;
            gameBoard[i - 1][j + 1] = DOT;
            gameBoard[i][j + 1] = DOT;

            // bottom right
        } else if (i == (gameBoard.length - 1) && j == (gameBoard[0].length - 1)) {
            gameBoard[i - 1][j - 1] = DOT;
            gameBoard[i][j - 1] = DOT;
            gameBoard[i - 1][j] = DOT;

            // bottom margin
        } else if (i == gameBoard.length - 1) {
            gameBoard[i][j - 1] = DOT;
            gameBoard[i][j + 1] = DOT;
            gameBoard[i - 1][j - 1] = DOT;
            gameBoard[i - 1][j] = DOT;
            gameBoard[i - 1][j + 1] = DOT;

            // left margin
        } else if (j == 0) {
            gameBoard[i - 1][j] = DOT;
            gameBoard[i - 1][j + 1] = DOT;
            gameBoard[i][j + 1] = DOT;
            gameBoard[i + 1][j] = DOT;
            gameBoard[i + 1][j + 1] = DOT;

            // right margin
        } else if (j == gameBoard[0].length - 1) {
            gameBoard[i - 1][j] = DOT;
            gameBoard[i - 1][j - 1] = DOT;
            gameBoard[i][j - 1] = DOT;
            gameBoard[i + 1][j - 1] = DOT;
            gameBoard[i + 1][j] = DOT;

            // middle
        } else {
            gameBoard[i - 1][j - 1] = DOT;
            gameBoard[i - 1][j] = DOT;
            gameBoard[i - 1][j + 1] = DOT;
            gameBoard[i][j - 1] = DOT;
            gameBoard[i][j + 1] = DOT;
            gameBoard[i + 1][j - 1] = DOT;
            gameBoard[i + 1][j] = DOT;
            gameBoard[i + 1][j + 1] = DOT;

        }
    }

    /**
     * Determines if there are any valid moves on the board that a
     * player can make. This function is used to check if the game
     * has ended.
     *
     * @return true if the player can make a move
     */
    public boolean anyMovesPossible() {

        for (int i = 0; i < gameBoard.length; i++) {
            for (int j = 0; j < gameBoard[0].length; j++) {
                if (gameBoard[i][j] == EMPTY) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * This is a getter method that returns a copy of the game board.
     *
     * @return a copy of the current state of the board
     */

    public char[][] getBoard() {

        char[][] matrix = new char[gameBoard.length][gameBoard[0].length];

        for (int i = 0; i < gameBoard.length; i++) {
            matrix[i] = Arrays.copyOf(gameBoard[i], gameBoard[i].length);
        }
        return matrix;
    }

    /**
     * This method updates the screen variable to represent the player
     * move in the specified cell as large ascii characters.
     *
     * @param row row number of cell
     * @param col column number of cell
     */

    public void updateScreen(int row, int col) {

        if (row < 0 || col < 0 || row >= gameBoard.length || col >= gameBoard[0].length) {
            return;
        }

        if (gameBoard[row][col] == CIRCLE) {
            screen[row * numPixels][col * numPixels + 1] = PLUS;
            screen[row * numPixels][col * numPixels + 2] = PLUS;
            screen[row * numPixels][col * numPixels + 3] = PLUS;
            screen[row * numPixels][col * numPixels + 4] = PLUS;
            screen[row * numPixels + 1][col * numPixels] = PLUS;
            screen[row * numPixels + 2][col * numPixels] = PLUS;
            screen[row * numPixels + 3][col * numPixels] = PLUS;
            screen[row * numPixels + 4][col * numPixels] = PLUS;
            screen[row * numPixels + 1][col * numPixels + 5] = PLUS;
            screen[row * numPixels + 2][col * numPixels + 5] = PLUS;
            screen[row * numPixels + 3][col * numPixels + 5] = PLUS;
            screen[row * numPixels + 4][col * numPixels + 5] = PLUS;
            screen[row * numPixels + 5][col * numPixels + 1] = PLUS;
            screen[row * numPixels + 5][col * numPixels + 2] = PLUS;
            screen[row * numPixels + 5][col * numPixels + 3] = PLUS;
            screen[row * numPixels + 5][col * numPixels + 4] = PLUS;
        }

        if (gameBoard[row][col] == CROSS) {
            screen[row * numPixels][col * numPixels] = STAR;
            screen[row * numPixels + 1][col * numPixels + 1] = STAR;
            screen[row * numPixels + 2][col * numPixels + 2] = STAR;
            screen[row * numPixels + 3][col * numPixels + 3] = STAR;
            screen[row * numPixels + 4][col * numPixels + 4] = STAR;
            screen[row * numPixels + 5][col * numPixels + 5] = STAR;
            screen[row * numPixels][col * numPixels + 5] = STAR;
            screen[row * numPixels + 1][col * numPixels + 4] = STAR;
            screen[row * numPixels + 2][col * numPixels + 3] = STAR;
            screen[row * numPixels + 3][col * numPixels + 2] = STAR;
            screen[row * numPixels + 4][col * numPixels + 1] = STAR;
            screen[row * numPixels + 5][col * numPixels] = STAR;

        }


        // top left
        if (row == 0 && col == 0) {
            for (int i = 0; i < numPixels; i++) {
                for (int j = 0; j < numPixels; j++) {
                    screen[row + i][col + j + numPixels] = DOT; // right
                    screen[row + i + numPixels][col + j + numPixels] = DOT; // bot right
                    screen[row + i + numPixels][col + j] = DOT; // bot
                }
            }

            // top right
        } else if (row == 0 && col * numPixels == (gameBoard[0].length * numPixels - numPixels)) {
            for (int i = 0; i < numPixels; i++) {
                for (int j = 0; j < numPixels; j++) {
                    screen[row + i][col * numPixels - numPixels + j] = DOT; // left
                    screen[row * numPixels + numPixels + i][col * numPixels - numPixels + j] = DOT; // bot left
                    screen[row + i + numPixels][col * numPixels + j] = DOT; // bot
                }

            }

            // top margin
        } else if (row == 0) {
            for (int i = 0; i < numPixels; i++) {
                for (int j = 0; j < numPixels; j++) {
                    screen[row + i][col * numPixels - numPixels + j] = DOT; // left
                    screen[row + i][col * numPixels + numPixels + j] = DOT; // right
                    screen[row * numPixels + numPixels + i][col * numPixels - numPixels + j] = DOT; // bot left
                    screen[row + i + numPixels][col * numPixels + numPixels + j] = DOT; // bot right
                    screen[row + i + numPixels][col * numPixels + j] = DOT; // bot mid
                }
            }

            // bot left
        } else if (row * numPixels == (gameBoard.length * numPixels - numPixels) && col == 0) {
            for (int i = 0; i < numPixels; i++) {
                for (int j = 0; j < numPixels; j++) {
                    screen[row * numPixels - numPixels + i][col * numPixels + numPixels + j] = DOT; // top right
                    screen[row * numPixels - numPixels + i][col + j] = DOT; //  top
                    screen[row * numPixels + i][col * numPixels + numPixels + j] = DOT; // right
                }
            }

            // bottom right
        } else if (row * numPixels == (gameBoard.length * numPixels - numPixels) &&
                col * numPixels == (gameBoard[0].length * numPixels - numPixels)) {
            for (int i = 0; i < numPixels; i++) {
                for (int j = 0; j < numPixels; j++) {
                    screen[row * numPixels - numPixels + i][col * numPixels + j] = DOT; // top
                    screen[row * numPixels - numPixels + i][col * numPixels - numPixels + j] = DOT; // top left
                    screen[row * numPixels + i][col * numPixels - numPixels + j] = DOT; //left

                }
            }

            // bot margin
        } else if (row * numPixels == (gameBoard.length * numPixels - numPixels)) {
            for (int i = 0; i < numPixels; i++) {
                for (int j = 0; j < numPixels; j++) {
                    screen[row * numPixels - numPixels + i][col * numPixels + j] = DOT; // top
                    screen[row * numPixels - numPixels + i][col * numPixels - numPixels + j] = DOT; // top left
                    screen[row * numPixels - numPixels + i][col * numPixels + numPixels + j] = DOT; // top right
                    screen[row * numPixels + i][col * numPixels - numPixels + j] = DOT; // left
                    screen[row * numPixels + i][col * numPixels + numPixels + j] = DOT; // right
                }
            }

            // left margin
        } else if (col == 0) {
            for (int i = 0; i < numPixels; i++) {
                for (int j = 0; j < numPixels; j++) {
                    screen[row * numPixels - numPixels + i][col + j] = DOT; // top
                    screen[row * numPixels + numPixels + i][col + j] = DOT; // bot
                    screen[row * numPixels - numPixels + i][col * numPixels + numPixels + j] = DOT; // top right
                    screen[row * numPixels + numPixels + i][col * numPixels + numPixels + j] = DOT; // bot right
                    screen[row * numPixels + i][col * numPixels + numPixels + j] = DOT; // right
                }
            }

            // right margin
        } else if (col * numPixels == (gameBoard[0].length * numPixels - numPixels)) {
            for (int i = 0; i < numPixels; i++) {
                for (int j = 0; j < numPixels; j++) {
                    screen[row * numPixels - numPixels + i][col * numPixels + j] = DOT; // top
                    screen[row * numPixels - numPixels + i][col * numPixels - numPixels + j] = DOT; // top left
                    screen[row * numPixels + i][col * numPixels - numPixels + j] = DOT; // left
                    screen[row * numPixels + numPixels + i][col * numPixels - numPixels + j] = DOT; // bot left
                    screen[row * numPixels + numPixels + i][col * numPixels + j] = DOT; // bot
                }
            }
        }

        // middle
        else {
            for (int i = 0; i < numPixels; i++) {
                for (int j = 0; j < numPixels; j++) {
                    screen[row * numPixels + numPixels + i][col * numPixels + j] = DOT; // bot
                    screen[row * numPixels - numPixels + i][col * numPixels + j] = DOT; // top
                    screen[row * numPixels - numPixels + i][col * numPixels + numPixels + j] = DOT; // top right
                    screen[row * numPixels - numPixels + i][col * numPixels - numPixels + j] = DOT; // top left
                    screen[row * numPixels + numPixels + i][col * numPixels + numPixels + j] = DOT; // bot right
                    screen[row * numPixels + numPixels + i][col * numPixels - numPixels + j] = DOT; // bot left
                    screen[row * numPixels + i][col * numPixels + numPixels + j] = DOT; // right
                    screen[row * numPixels + i][col * numPixels - numPixels + j] = DOT; // left


                }
            }
        }
    }

    /**
     * This is a getter method that returns of copy of the screen.
     *
     * @return a copy of the current state of the screen
     */
    public char[][] getScreen() {

        char[][] matrix = new char[gameBoard.length * numPixels][gameBoard[0].length * numPixels];

        for (int i = 0; i < gameBoard.length * numPixels; i++) {
            matrix[i] = Arrays.copyOf(screen[i], screen[i].length);
        }
        return matrix;
    }

    /**
     * This method prints a pretty version of the board to the
     * console. While we are giving this method to you, feel free to
     * edit it if you are confident enough in your coding abilities.
     */
    public void printBoard() {
        char[][] board = getBoard();

        if (!usingLargeBoard) {
            // Make the header of the board
            System.out.printf("\n ");
            for (int i = 0; i < board[0].length; ++i)
                System.out.printf("   %d", i);
            System.out.println();

            System.out.printf("  ");
            for (int i = 0; i < board[0].length; ++i)
                System.out.printf("----");
            System.out.println("-");

            // Print the board contents
            for (int i = 0; i < board.length; ++i) {
                System.out.printf("%c ", 'A' + i);
                for (int k = 0; k < board[0].length; ++k)
                    System.out.printf("| %c ", board[i][k]);
                System.out.println("|");

                // print the line between each row
                System.out.printf("  ");
                for (int k = 0; k < board[0].length; ++k)
                    System.out.printf("----");
                System.out.println("-");
            }
        } else { // where we are printing the large board

            // Make the header of the board
            System.out.println();
            for (int i = 0; i < board[0].length; ++i) {
                for (int k = 0; k < numPixels; ++k)
                    System.out.printf(" ");
                System.out.printf("%d", i);
            }
            System.out.println();

            System.out.printf("  ");
            for (int i = 0; i < board[0].length; ++i) {
                for (int k = 0; k < numPixels + 1; ++k)
                    System.out.printf("-");
            }
            System.out.println("-");

            // Print the board contents
            for (int i = 0; i < screen.length; ++i) {
                System.out.printf("%c |", i % numPixels == numPixels / 2 ?
                        'A' + i / numPixels : EMPTY);

                // print the row of the screen
                for (int k = 0; k < screen[0].length; ++k) {
                    System.out.printf("%c", screen[i][k]);
                    if ((k + 1) % numPixels == 0)
                        System.out.print("|");
                }
                System.out.println();

                // print the line between each row
                if ((i + 1) % numPixels == 0) {
                    System.out.printf("  ");
                    for (int j = 0; j < board[0].length; ++j) {
                        for (int k = 0; k < numPixels + 1; ++k)
                            System.out.printf("-");
                    }
                    System.out.println("-");
                }
            }
        }
    }

    /**
     * This method initiates gameplay.
     */

    public void play() {

        char currentPlayer = CROSS;

        // Begin playing the game
        Scanner in = new Scanner(System.in);
        do {
            currentPlayer = currentPlayer == CIRCLE ? CROSS : CIRCLE;
            this.printBoard();
            System.out.printf("Current player: '%c'\n", currentPlayer);

            // read and validate the input
            int row = -1;
            int col = -1;
            do {
                System.out.printf("Choose a move location: ");
                String line = in.nextLine();

                if (line == null)
                    continue;

                // Check for special commands
                if (line.equals("switch")) {
                    usingLargeBoard = !usingLargeBoard;
                    System.out.printf("Big Board display is %s.\n",
                            usingLargeBoard ? "on" : "off");
                    this.printBoard();
                    continue;
                } else if (line.equals("end")) {
                    System.out.printf("Game is manually ending.\n");
                    return;
                } else if (line.contains("=")) {
                    String[] parts = line.split("=");
                    if (parts.length == 2 && parts[0].equals("pixels")) {
                        // Change the number of pixels in the big board

                        if ((new Scanner(parts[1])).hasNextInt()) {
                            if (Integer.parseInt(parts[1]) < 3)
                                continue;
                            numPixels = Integer.parseInt(parts[1]);
                        } else
                            continue;

                        System.out.printf("Big Board cell sizes are "
                                + "now %sx%s pixels.\n", parts[1], parts[1]);

                        screen = new char[numPixels * gameBoard.length]
                                [numPixels * gameBoard[0].length];
                        for (int i = 0; i < screen.length; ++i) {
                            for (int j = 0; j < screen[i].length; ++j) {
                                screen[i][j] = EMPTY;
                            }
                        }

                        for (int i = 0; i < gameBoard.length; ++i)
                            for (int j = 0; j < gameBoard[i].length; ++j)
                                this.updateScreen(i, j);

                        if (usingLargeBoard)
                            this.printBoard();
                    }

                    continue;
                } else if (line.length() != 2)
                    continue;

                row = line.charAt(0) - 'A';
                col = line.charAt(1) - '0';

            } while (!this.playAtLocation(row, col, currentPlayer));

        } while (this.anyMovesPossible());

        this.printBoard();
        System.out.printf("\n!!! Winner is Player '%c' !!!\n", currentPlayer);
        in.close();
    }
}