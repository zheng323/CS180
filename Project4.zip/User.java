import java.util.Random;

/**
 * @author (Kenny Zheng) <(zheng323@purdue.edu)>, Tinghao
 */
public class User {
    String username;
    String password;
    Random r = new Random();
    long id = r.nextLong();
   // Email[] emailArray = new Email[numEmail];
    DynamicBuffer bf;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.bf = new DynamicBuffer(10);
    }

    public String getName() {
        return username;
    }

    public boolean checkPassword(String password) {
        if (this.password.equals(password)) {
            return true;
        }
        return false;

    }

    public int numEmail() {

        return bf.numElements();
    }

    public void receiveEmail(String sender, String message) {

        Email em = new Email(username, sender, id, message);
        bf.add(em);

    }

    public Email[] retrieveEmail(int n) {

        //DynamicBuffer df = new DynamicBuffer(numEmail);
        return bf.getNewest(n);
    }

    public boolean removeEmail(long emailID) {

//        for (int i = 0; i <= numEmail; i++) {
//            if (emailArray[i].getID() == emailID) {
//                bf.remove(i);
//                numEmail--;
//                return true;
//            }
//        }
        int index = bf.getIndexEmail(emailID);

        if (index == -1) {
            return false;
        } else {
            return bf.remove(index);
        }
    }
}
