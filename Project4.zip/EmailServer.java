import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.management.BufferPoolMXBean;
import java.net.FileNameMap;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/**
 * <b> CS 180 - Project 4 - Email Server Skeleton </b>
 * <p>
 * <p>
 * This is the skeleton code for the EmailServer Class. This is a private email
 * server for you and your friends to communicate.
 *
 * @author (Kenny Zheng) <(zheng323@purdue.edu)>, Tinghao
 * @version (Today's Date)
 * @lab (Your Lab Section)
 */

public class EmailServer {

    public User[] users;
    public Email[] email;
    int currentUser = 0;
    private String file;

    public EmailServer() {

        users = new User[100];
        users[currentUser] = new User("root", "cs180");
        currentUser++;
    }

    public EmailServer(String fileName) throws IOException {
        this();
        this.file = fileName;

        try {
            Path p = Paths.get(fileName);
            Files.createFile(p);
        } catch (Exception e) {
            String str;
            String stringArry[];
            FileReader fr = new FileReader(fileName);
            BufferedReader br = new BufferedReader(fr);
            while ((str = br.readLine()) != null) {
                stringArry = str.split(",");
                if (stringArry.length == 2) {
                    addUser(new String[] {"ADD-USER", stringArry[0], stringArry[1]});
                } else
                    continue;
            }

            br.close();
        }
    }

    // Useful constants
    public static final String FAILURE = "FAILURE";
    public static final String DELIMITER = "\t";
    public static final String SUCCESS = "SUCCESS";
    public static final String CRLF = "\r\n";

    // Used to print out extra information
    private boolean verbose = false;


    public void run() {
        Scanner in = new Scanner(System.in);

        while (true) {
            System.out.printf("Input Server Request: ");
            String command = in.nextLine();

            command = replaceEscapeChars(command);

            if (command.equalsIgnoreCase("kill") || command.equalsIgnoreCase("kill\r\n"))
                break;

            if (command.equalsIgnoreCase("verbose") || command.equalsIgnoreCase("verbose\r\n")) {
                verbose = !verbose;
                System.out.printf("VERBOSE has been turned %s.\n\n", verbose ? "on" : "off");
                continue;
            }

            String response = null;
            try {
                response = parseRequest(command);
            } catch (Exception ex) {
                response = ErrorFactory.makeErrorMessage(ErrorFactory.UNKNOWN_ERROR,
                        String.format("An exception of %s occurred.", ex.getClass().toString()));
            }

            //if (response.startsWith("SUCCESS" + DELIMITER))
            //	response = response.replace(DELIMITER, NEWLINE);
            if (response.startsWith(FAILURE) && !DELIMITER.equals("\t"))
                response = response.replace(DELIMITER, "\t");

            if (verbose)
                System.out.print("response: ");
            System.out.printf("\"%s\"\n\n", response);
        }

        in.close();
    }

    /**
     * Determines which client command the request is using and calls
     * the function associated with that command.
     *
     * @param request - the full line of the client request (CRLF included)
     * @return the server response
     */


    public String parseRequest(String request) {

        if (request == null) {
            return ErrorFactory.makeErrorMessage(-11);
        }

        if (!request.endsWith(CRLF)) {
            return ErrorFactory.makeErrorMessage(-10);
        }

        request = request.trim();

        String[] command = request.split("\t");

        if (command.length < 3) {
            return ErrorFactory.makeErrorMessage(-10);
        }

        if (command[0].equals("ADD-USER")) {
            if (command.length != 3) {
                return ErrorFactory.makeErrorMessage(-10);
            }

        } else if (command[0].equals("DELETE-USER")) {
            if (command.length != 3) {
                return ErrorFactory.makeErrorMessage(-10);
            }

        } else if (command[0].equals("GET-ALL-USERS")) {
            if (command.length != 3) {
                return ErrorFactory.makeErrorMessage(-10);
            }

        } else if (command[0].equals("SEND-EMAIL")) {
            if (command.length != 5) {
                return ErrorFactory.makeErrorMessage(-10);
            }

        } else if (command[0].equals("GET-EMAILS")) {
            if (command.length != 4) {
                return ErrorFactory.makeErrorMessage(-10);
            }

        } else if (command[0].equals("DELETE-EMAIL")) {
            if (command.length != 4) {
                return ErrorFactory.makeErrorMessage(-10);
            }
        } else {
            return ErrorFactory.makeErrorMessage(-11);
        }

        boolean userExist = true;

        if (command[0].equals("ADD-USER")) {
            if (command[1].equals("root")) {
                return ErrorFactory.makeErrorMessage(-22);
            }

            for (int i = 0; i < currentUser; i++) {
                if (command[i].equals(users[i].getName())) {
                    userExist = true;
                } else
                    userExist = false;
            }

            if (userExist) {
                return ErrorFactory.makeErrorMessage(-22);
            } else {
                return addUser(command);
            }
        }
//            for (User userName : users) { // check user exists
//                if (userName.equals(command[1])) {
//                    return ErrorFactory.makeErrorMessage(-22);
//                } else {
//                    return addUser(command);
//                }
//            }


        for (User userName : users) {
            if (userName == null) {
                break;
            }
            if (command[1].equals(userName.getName())) {
                if (userName.checkPassword(command[2])) {
                    if (command[0].equals("DELETE-USER")) {
                        return deleteUser(command);
                    } else if (command[0].equals("GET-ALL-USERS")) {
                        return getAllUsers(command);
                    } else if (command[0].equals("SEND-EMAIL")) {
                        return sendEmail(command);
                    } else if (command[0].equals("GET-EMAILS")) {
                        return getEmails(command);
                    } else if (command[0].equals("DELETE-EMAIL")) {
                        return deleteEmail(command);
                    }
                } else
                    return ErrorFactory.makeErrorMessage(-21);

            }

        }

        return ErrorFactory.makeErrorMessage(-20);

//
//        if (!command[1].contains("^[a-zA-Z0-9]*$")) {
//            return ErrorFactory.makeErrorMessage(-23);
//        }
//
//        return ErrorFactory.makeErrorMessage(-21);
    }

    public String addUser(String[] args) {

        if (args == null) {
            return ErrorFactory.makeErrorMessage(-11);
        }

        if (args.length != 3) {
            return ErrorFactory.makeErrorMessage(-10);
        }


        String userName = args[1];
        String passWord = args[2];


        if (userName.equals("root")) {
            return ErrorFactory.makeErrorMessage(-22);
        }

        if (!userName.matches("^[a-zA-Z0-9]*$") || !passWord.matches("^[a-zA-Z0-9]*$")) { // check valid username
            return ErrorFactory.makeErrorMessage(-23);
        }

        if (userName.length() < 1 || userName.length() > 20) { // check username length
            return ErrorFactory.makeErrorMessage(-23);
        }

        if (passWord.length() < 4 || passWord.length() > 40) { // check password length
            return ErrorFactory.makeErrorMessage(-23);
        }

        // check user exists
        for (int i = 0; i <= currentUser; i++) {
            if (userName.equals(users[i])) {
                return ErrorFactory.makeErrorMessage(-22);
            }
        }

        users[currentUser++] = new User(userName, passWord);
        return SUCCESS + CRLF;


    }

    public String getAllUsers(String[] args) {

        if (args == null) {
            return ErrorFactory.makeErrorMessage(-11);
        }

        if (args.length != 3) {
            return ErrorFactory.makeErrorMessage(-10);
        }

        String name = "";

        for (int i = 0; i < currentUser; i++) {
            name += "\t" + users[i].getName(); // return result

        }

        return SUCCESS + name + CRLF;
    }

//        for (User name : users) {
//            if (userName.equals(name.getName())) { // check username
//                if (name.checkPassword(passWord)) { // check password
//                    System.out.println(name.getName() + "\t" + "user" + counter); // return result
//                    counter++;
//                }
//                return ErrorFactory.makeErrorMessage(-21);
//            }
//            return ErrorFactory.makeErrorMessage(-20);
//        }
//
//        for (int i = 0; i < users.length; i++) {
//            if ((!userName.equals(users[i].getName()))) {
//                return ErrorFactory.makeErrorMessage(-20);
//            }
//        }
//
//        for (int i = 0; i < users.length; i++) {
//            if (users[i].getName().equals(userName) && users[i].checkPassword(passWord)) {
//                for (int j = 0; j < users.length; j++) {
//                    System.out.println("" + users[j].getName() + "\t");
//                }
//            }
//
//            return SUCCESS + CRLF;
//        }


    public String deleteUser(String[] args) {

        if (args == null) {
            return ErrorFactory.makeErrorMessage(-11);
        }

        if (args.length != 3) {
            return ErrorFactory.makeErrorMessage(-10);
        }

        String userName = args[1];
        String passWord = args[2];
        int location = 0;

        if (userName.equals("root")) {
            return ErrorFactory.makeErrorMessage(-23);
        }

        // check user exists
        for (int i = 1; i < currentUser; i++) {
            if (userName.equals(users[i].getName())) {
                if (users[i].checkPassword(passWord)) {
                    location = i;
                }
            } else {
                location = -1;
            }
        }

        if (location == -1) {
            return ErrorFactory.makeErrorMessage(-20);
        }

        for (int i = location; i <= currentUser; i++) {
            users[i] = users[i + 1];
            users[users.length - 1] = null;
        }

        return SUCCESS + CRLF;
    }


//        for (int i = 1; i <= currentUser; i++) {
//            if (userName.equals(users[i].getName())) { // check username
//                if (users[i].checkPassword(passWord)) { // check password
//                    users[i] = users[i + 1]; // set current user to the next user
//                    users[users.length - 1] = null; // set last user to null
//                    currentUser --;
//                    return SUCCESS + CRLF;
//                }
//                return ErrorFactory.makeErrorMessage(-21);
//            }
//            return ErrorFactory.makeErrorMessage(-20);
//        }
//
//        return ErrorFactory.makeErrorMessage(-1);
//    }
//        for (int i = 0; i < users.length; i++) {
//            if ((!userName.equals(users[i].getName()))) {
//                return ErrorFactory.makeErrorMessage(-20);
//            }
//        }
//
//        for (int i = 0; i < users.length; i++) {
//            if (userName.equals(users[i].getName())) {
//                if (users[i].checkPassword(passWord)) {
//                    users[i].username = null;
//                    users[i].password = null;
//                    for (int j = i; j < users.length; j++) {
//                        users[j].username = users[j + 1].username;
//                        users[j].password = users[j + 1].password;
//                        users[users.length - 1].username = null;
//                        users[users.length - 1].password = null;
//                    }
//                }
//            }
//
//            return SUCCESS + CRLF;
//        }
//
//        return ErrorFactory.makeErrorMessage(-20);


    public String sendEmail(String[] args) {

        if (args.length != 5) {
            return ErrorFactory.makeErrorMessage(-10);
        }

        String userName = args[1];
        String passWord = args[2];
        String recipient = args[3];
        String messageOld = args[4];
        String message = messageOld.trim();
        User u = new User(userName, passWord);

        if (message.length() < 1) {
            return ErrorFactory.makeErrorMessage(-10);
        }

//        for (User name : users) {
//            if (recipient.equals(name.getName())) {
//                name.receiveEmail(userName, message);
//                return SUCCESS + CRLF;
//            }
//        }
//
//        return ErrorFactory.makeErrorMessage(-1);
//    }
//
//        for (User name : users) {
//
//            if (recipient.equals(name.getName())) { // check valid recipient
//                name.receiveEmail(userName, message); // send message
//                return SUCCESS + CRLF;
//            }
//            return ErrorFactory.makeErrorMessage(-20); // recipient doesn't exist
//
//        }

        boolean userExist = true;

        int target = -1;
        for (int i = 0; i < currentUser; i++) {
            if (recipient.equals(users[i].getName())) {
                userExist = true;
                target = i;
            } else
                userExist = false;
        }

        if (userExist) {
            users[target].receiveEmail(userName, message);
            return SUCCESS + CRLF;
        } else {
            return ErrorFactory.makeErrorMessage(-20);
        }

    }

    public String getEmails(String[] args) {

        if (args.length != 4) {
            return ErrorFactory.makeErrorMessage(-11);
        }

        String userName = args[1];
        String passWord = args[2];
        String num = args[3];

        String email = "";
        int numMessages = 0;


        try {
            numMessages = Integer.parseInt(num);
        } catch (NumberFormatException e) {
            System.out.println("");
        }

        if (numMessages <= 0) {
            return ErrorFactory.makeErrorMessage(-23);
        }

        for (int i = 0; i < users.length; i++) {
            if (userName.equals(users[i].getName())) {
                if (users[i].retrieveEmail(numMessages) == null) {
                    return SUCCESS + CRLF;
                } else if (users[i].numEmail() < numMessages) {
                    numMessages = users[i].numEmail();
                }
                Email[] e = users[i].retrieveEmail(numMessages);
                for (int j = 0; j < e.length; j++) {
                    email += e[j].toString() + DELIMITER;
                }

                break;
            }
        }

//        for (int i = 0; i < u.numEmail(); i++) {
//            email += u.retrieveEmail(numMessages).toString();
//
//        }

        return SUCCESS + DELIMITER + email + CRLF;

//        if (numMessages > u.numEmail) { // request > total email
//            email += u.retrieveEmail(u.numEmail).toString(); // return email
//        }
//
//
//        for (User name : users) {
//            if (userName.equals(name.getName())) { // check username
//                if (name.checkPassword(passWord)) { // check password
//                    return u.retrieveEmail(u.numEmail).toString(); // return e-mail
//                }
//
//                return ErrorFactory.makeErrorMessage(-21); // wrong password
//            }
//
//            return ErrorFactory.makeErrorMessage(-20); // username doesn't exist
//        }
//
//        return ErrorFactory.makeErrorMessage(-1);
    }

    public String deleteEmail(String[] args) {

        if (args.length != 4) {
            return ErrorFactory.makeErrorMessage(-23);
        }

        String userName = args[1];
        String passWord = args[2];
        String emailsID = args[3];
        long emailID = 0;
        try {
            emailID = Long.parseLong(emailsID);
        } catch (NumberFormatException e) {
            System.out.println("");
        }

        if (userName.equals("root")) {
            return ErrorFactory.makeErrorMessage(-23);
        }

        for (int i = 0; i < users.length; i++) {
            if (userName.equals(users[i].getName())) {
                users[i].removeEmail(emailID);
                return SUCCESS + CRLF;
            }
        }

        return ErrorFactory.makeErrorMessage(-1);
    }

//        User u = new User(userName, passWord);
//
//        for (User user : users) {
//            if (userName.equals(user.getName())) {
//                user.removeEmail(emailID);
//                return SUCCESS + CRLF;
//
//            }
//        }
//
//        return ErrorFactory.makeErrorMessage(-1);

//        for (int i = 0; i < users.length; i++) {
//            if (userName.equals(users[i].getName())) {
//                if (users[i].checkPassword(passWord)) {
//                    if (email[i].getID() == emailID) {
//                        email[i] = null;
//                        for (int j = i; j < email.length; j++) {
//                            email[j] = email[j + 1];
//                            email[email.length - 1] = null;
//                        }
//                    }
//                }
//            }
//
//            return SUCCESS + CRLF;
//        }
//
//        return ErrorFactory.makeErrorMessage(-1);
//    }

    /**
     * Replaces "poorly formatted" escape characters with their proper
     * values. For some terminals, when escaped characters are
     * entered, the terminal includes the "\" as a character instead
     * of entering the escape character. This function replaces the
     * incorrectly inputed characters with their proper escaped
     * characters.
     *
     * @param str - the string to be edited
     * @return the properly escaped string
     */
    private static String replaceEscapeChars(String str) {
        str = str.replace("\\r\\n", "\r\n"); // may not be necessary, but just in case
        str = str.replace("\\r", "\r");
        str = str.replace("\\n", "\n");
        str = str.replace("\\t", "\t");
        str = str.replace("\\f", "\f");

        return str;
    }

    /**
     * This main method is for testing purposes only.
     *
     * @param args - the command line arguments
     */
    public static void main(String[] args) {
        (new EmailServer()).run();
    }
}