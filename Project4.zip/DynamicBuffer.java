import java.util.Arrays;

/**
 * @author (Kenny Zheng) <(zheng323@purdue.edu)>, Tinghao
 */
public class DynamicBuffer {

    Email[] emailArray;
    private int size;

    public DynamicBuffer(int initSize) {
        this.emailArray = new Email[initSize];
        //System.out.println("start: "+initSize);
    }

    public int numElements() {

//        int numOfEmail = 0;
//        for (int i = 0; i < emailArray.length; i++) {
//            if (emailArray[i] != null) {
//                numOfEmail++;
//            }
//        }

        return size;
    }

    public int getBufferSize() {

        return this.emailArray.length;
    }

    public int getIndexEmail(long emailID) {
        //
        for (int i = 0; i < numElements(); i++) {
            if (emailArray[i].getID() == emailID) {
                return i;
            }
        }
        return -1;
    }

    public void add(Email email) {

        // expand size
        if (numElements() + 1 == this.emailArray.length) {
            Email[] temp = this.emailArray;
            Email[] newEmailArray = new Email[this.emailArray.length * 2];
            for (int i = 0; i < temp.length; i++) {
                newEmailArray[i] = temp[i];
            }
            emailArray = newEmailArray;
        }

        for (int i = 0; i < emailArray.length; i++) {
            if (emailArray[i] == null) {
                emailArray[i] = email;
                size ++;
                break;
            }
        }
        //System.out.println(emailArray.length);
    }


    public boolean remove(int index) {

        if (index < emailArray.length && emailArray[index] != null) {
            emailArray[index] = null;
            // shift everything to the left
            for (int i = index; i < emailArray.length; i++) {
                if (i < emailArray.length - 1) {
                    emailArray[i] = emailArray[i + 1];
                } else {
                    emailArray[emailArray.length - 1] = null;
                }

            }

            // check how many emails in the array
            int counter = 0;
            for (int i = 0; i < emailArray.length; i++) {
                if (emailArray[i] != null) {
                    counter++;
                }
            }

            // strink the array
            if (counter <= emailArray.length / 4) {
                Email[] temp = new Email[emailArray.length / 2];
                temp = Arrays.copyOf(emailArray, emailArray.length / 2);
                emailArray = temp;
            }

            size --;
            return true;
        }

        return false;
    }

    public Email[] getNewest(int n) {

        n = Math.min(numElements(), n);

        if (n <= 0) {
            return null;
        }
        if (n >= numElements()) {
            n = numElements();
        }
        //System.out.println("numElements: " +numElements() );
        //System.out.println("num emails available : " + numElements() + " requested is " + n);
        Email[] returnNewest = new Email[n];
        if (emailArray.length == 0) {
            return null;
        } else {
            for (int i = 0; i < n; i++) {
                returnNewest[i] = emailArray[numElements() - 1 - i];
            }
        }

        return returnNewest;
    }
}