import java.io.IOException;
import java.util.Scanner;
import cs180.net.Socket;
import cs180.net.ServerSocket;

/**
 * @author (Kenny Zheng) <(zheng323@purdue.edu)>, Tinghao
 */
public class OnlineEmailServer extends EmailServer {

    private boolean verbose = true;

    public OnlineEmailServer(String filename, int port) throws IOException {

        super(filename);
        ServerSocket ss = new ServerSocket(port);
        ss.setReuseAddress(true);
    }

    public void processClient(Socket client) throws IOException {

    }

}