import javax.print.attribute.standard.DateTimeAtCreation;
import java.util.Date;

/**
 * @author (Kenny Zheng) <(zheng323@purdue.edu)>, Tinghao
 */
import java.util.Date;
public class Email {
    String recipient;
    String sender;
    long id;
    String message;

    public String getOwner() {
        return recipient;
    }

    public String getSender() {
        return sender;
    }

    public long getID() {
        return id;
    }

    public String getMessage() {
        return message;
    }
    public String toString() {
        DateTimeAtCreation date = new DateTimeAtCreation(new Date());
        return String.format("" + id + ";" + date + ";" + " From: " + sender + " " + "\"" + message + "\"");
    }

    public Email(String recipient, String sender, long id, String message) {
        this.recipient = recipient;
        this.sender = sender;
        this.id = id;
        this.message = message;

    }
}