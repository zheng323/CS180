/**
 * Created by KennyZheng on 1/30/16.
 */

public class FAFSA {

    boolean isAcceptedStudent;
    boolean isSSregistered;
    boolean hasSSN;
    boolean hasValidResidency;
    Boolean isDependent;
    int age;
    int creditHours;
    double studentIncome;
    double parentIncome;
    String classStanding;

    public FAFSA(boolean isAcceptedStudent, boolean isSSregistered,
                 boolean hasSSN, boolean hasValidResidency, Boolean isDependent,
                 int age, int creditHours, double studentIncome, double parentIncome,
                 String classStanding) {
        this.isAcceptedStudent = isAcceptedStudent;
        this.isSSregistered = isSSregistered;
        this.hasSSN = hasSSN;
        this.hasValidResidency = hasValidResidency;
        this.isDependent = isDependent;
        this.age = age;
        this.creditHours = creditHours;
        this.studentIncome = studentIncome;
        this.parentIncome = parentIncome;
        this.classStanding = classStanding;
    }

    public boolean isFederalAidEligible() {

        boolean federalEligible;

        if (isAcceptedStudent && isSSregistered  && age >= 18 && age <= 26 && hasSSN && hasValidResidency) {
            federalEligible = true;
        } else if (isAcceptedStudent && hasSSN && hasValidResidency && age < 18 || age > 25) {
            federalEligible = true;
        } else {
            federalEligible = false;
        }

        return federalEligible;
    }

    public double calcEFC() {

        double calEFC;

        if (isDependent == true) {
            calEFC = studentIncome + parentIncome;
        } else {
            calEFC = studentIncome;
        }

        return  calEFC;
    }

    public double calcFederalGrant() {

        isFederalAidEligible();
        double totalGrant = 0;

        if (isFederalAidEligible() == false) {
            totalGrant = 0;
        }

        if (classStanding == null) {
            return 0;
        }

        if (classStanding.equalsIgnoreCase("undergraduate") && creditHours < 9) {
            totalGrant = 2500;
        } else if (classStanding.equalsIgnoreCase("graduate") && creditHours < 9) {
            totalGrant = 0;
        } else if (classStanding.equalsIgnoreCase("undergraduate") && creditHours >= 9) {
            totalGrant = 5775;
        } else if (classStanding.equalsIgnoreCase("graduate") && creditHours >= 9) {
            totalGrant = 0;
        } else {
            totalGrant = 0;
        }

        return totalGrant;
    }

    public double calcStaffordLoan() {

        double totalLoan = 0;

        if (classStanding == null) {
            return 0;
        }

        if (classStanding.equalsIgnoreCase("undergraduate") && isDependent == true && creditHours >= 9) {
            totalLoan = 5000;
        } else if (classStanding.equalsIgnoreCase("graduate") && isDependent == true && creditHours >= 9) {
            totalLoan = 10000;
        } else if (classStanding.equalsIgnoreCase("undergraduate") && isDependent == false && creditHours >= 9) {
            totalLoan = 10000;
        } else if (classStanding.equalsIgnoreCase("graduate") && isDependent == false && creditHours >= 9) {
            totalLoan = 20000;
        } else {
            totalLoan = 0;
        }

        return totalLoan;
    }

    public double calcWorkStudy() {

        calcEFC();
        double workStudy = 0;

        if (calcEFC() >= 0 && calcEFC() <= 30000.00) {
            workStudy = 1500;
        } else if (calcEFC() >= 30000.01 && calcEFC() <= 40000.00) {
            workStudy = 1000;
        } else if (calcEFC() >= 40000.01 && calcEFC() <= 50000.00) {
            workStudy = 500;
        } else if (calcEFC() > 50000.00) {
            workStudy = 0;
        }

        return workStudy;
    }

    public double calcFederalAidAmount() {

        isFederalAidEligible();
        calcEFC();
        calcFederalGrant();
        calcStaffordLoan();
        calcWorkStudy();

        double totalAmount;

        if (isFederalAidEligible() == false) {
            return 0;
        } else {
            totalAmount = calcFederalGrant() + calcStaffordLoan() + calcWorkStudy();
        }

        return totalAmount;
    }

}
