import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Created by KennyZheng on 4/18/16.
 */
public class Stats {

    public static Map wins (String filename) throws FileNotFoundException {

        FileInputStream fis = new FileInputStream(filename);
        BufferedReader br = new BufferedReader(new InputStreamReader(fis));
        Map<String, Integer> map = new HashMap<String, Integer>();
        String s;
        String[] str;

        try {
            while ((s = br.readLine()) != null) {
                str = s.split(" ");

                if (str[0].equals("0")) {
                    for (int i = 1; i < 6; i++) {
                        String name = str[i];
                        Integer count = map.get(name);
                        if (count == null) {
                            map.put(name, 0);
                        } else {
                            map.put(name, count + 1);
                        }
                    }
                } else if (str[0].equals("1")) {
                    for (int i = 7; i < 12; i++) {
                        String name = str[i];
                        Integer count = map.get(name);
                        if (count == null) {
                            map.put(name, 0);
                        } else {
                            map.put(name, count + 1);
                        }
                    }
                }
            }

        } catch (Exception e) {

        }

        return map;
    }

    public static String winner (Map m) {

        int count = 0;
        int win;
        String name;
        String nameWin = "";

        Set set = m.entrySet();
        Iterator iterator = set.iterator();

        while (iterator.hasNext()) {
            Map.Entry mEntry = (Map.Entry)iterator.next();
            win = (int) mEntry.getValue();
            name = (String) mEntry.getKey();

            if (win > count) {
                count = win;
                nameWin = name;
            }
        }

        return nameWin;
    }


}
