import java.util.Stack;

/**
 * Created by KennyZheng on 4/18/16.
 */
public class Evaluator {

    public static double evaluate (String s) {

        Stack<Double> stack = new Stack<Double>();
        String[] newArray = s.split(" ");

        for (String string : newArray) {
            if (string.matches("[0-9]")) {
                stack.push(Double.parseDouble(string));
            }
            else {
                double num2 = stack.pop();
                double num1 = stack.pop();

                if (string.equals("+")) {
                    stack.push(num1 + num2);
                } else if (string.equals("-")) {
                    stack.push(num1 - num2);
                } else if (string.equals("*")) {
                    stack.push(num1 * num2);
                } else if (string.equals("/")) {
                    stack.push(num1 / num2);
                } else {
                    throw new RuntimeException("Unknown operator");
                }
            }
        }

        return stack.pop();
    }

    public static void main(String[] args) {
        String s = "5 1 + 4 * 3 /";
        System.out.println("(" + s + ") = " + "" + evaluate(s));
    }
}
