import java.io.File;

/**
 * Created by KennyZheng on 4/25/16.
 */
public class Recursion {

    public static int filecount(File f) {

        int count = 0;
        if (f.isFile()) {
            count ++;
        } else {
            File[] files = f.listFiles();
            for (File file : files) {
                count += filecount(file);
            }
        }

        return count;
    }
}
