public class Contact {

    private String name;
    private long number;
    private String address;

    public Contact(String name) {
        this(name, 0, null);
    }

    public Contact(String name, long number) {
        this(name, number, null);
    }

    public Contact(String name, long number, String address) {
        this.name = name;
        this.number = number;
        this.address = address;
    }

    String getName() {
        return name;
    }

    void setName(String name) {
        this.name = name;
    }

    long getNumber() {
        return  number;
    }

    void setNumber(long number) {
        this.number = number;
    }

    String getAddress() {
        return address;
    }

    void setAddress(String address) {
        this.address = address;
    }

    boolean equals(Contact name) {
        if (this.name.equals(name)) {
            return true;
        }
        return false;
    }
}