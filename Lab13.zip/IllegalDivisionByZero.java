/**
 * Created by KennyZheng on 4/11/16.
 */
public class IllegalDivisionByZero extends Exception{

    public IllegalDivisionByZero (String message) {
        super(message);
    }

    public IllegalDivisionByZero() {
        super();
    }
}
