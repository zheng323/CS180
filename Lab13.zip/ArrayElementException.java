/**
 * Created by KennyZheng on 4/11/16.
 */
public class ArrayElementException extends Exception {

    public ArrayElementException(String message) {
        super(message);
    }

    public ArrayElementException() {
        super();
    }
}
