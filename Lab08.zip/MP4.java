import java.util.UUID;

/**
 * Created by KennyZheng on 2/28/16.
 */
public class MP4 implements Sellable, Downloadable {

    String productName;
    VideoType type;

    MP4(String productName, VideoType type) {
        this.productName = productName;
        this.type = type;
    }

    public String getProductName() {

        return productName;
    }

    public double getPrice() {

        if (this.type.equals(VideoType.MOVIE)) {
            return 4.99;
        } else if (this.type.equals(VideoType.TVSERIES)) {
            return 19.99;
        }

        return 0;
    }

    public String generateDownloadCode() {

        return UUID.randomUUID().toString();
    }

    public VideoType getType() {

        return type;
    }

}
