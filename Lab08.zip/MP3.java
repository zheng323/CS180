import java.util.UUID;

/**
 * Created by KennyZheng on 2/28/16.
 */
public class MP3 implements Sellable, Downloadable{

    String productName;

    MP3(String productName) {
        this.productName = productName;
    }

    public String getProductName() {
        return productName;

    }

    public double getPrice() {
        return 0.99;
    }

    public String generateDownloadCode() {
        return UUID.randomUUID().toString();
    }

}
