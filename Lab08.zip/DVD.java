/**
 * Created by KennyZheng on 2/28/16.
 */
public class DVD implements Sellable {

    double price;
    VideoType type;
    String productName;

    DVD(String productName, VideoType type, double price) {
        this.productName = productName;
        this.type = type;
        this.price = price;
    }

    public String getProductName() {
        return productName;
    }

    public double getPrice() {
        return price;
    }

    public VideoType getType() {
        return type;
    }
}
