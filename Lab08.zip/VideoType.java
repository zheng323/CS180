public enum VideoType {
    MOVIE, TVSERIES
}