/**
 * Created by KennyZheng on 2/28/16.
 */
public class CD implements Sellable {

    double price;
    int totalSongs;
    String productName;

    CD(String productName, int totalSongs, double price) {
        this.productName = productName;
        this. totalSongs = totalSongs;
        this. price = price;
    }

    public String getProductName() {
        return productName;
    }

    public double getPrice() {
        return price;
    }

    public int getTotalSongs() {
        return totalSongs;
    }
}
