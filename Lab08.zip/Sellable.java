/**
 * Created by KennyZheng on 2/28/16.
 */
public interface Sellable {

    String getProductName();


    double getPrice();
}
